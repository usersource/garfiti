 var pictureSource; 
    var destinationType;
		var message;
			var recipient;
				var subject;
					var ImageSrc;
						var attachment;
    // Wait for device API libraries to load
    document.addEventListener("deviceready",onDeviceReady,false);

    // device APIs are available
    //
	function changePage(){
		window.location = "input.html";
	}
    // Called when a photo is successfully retrieved
    //
    function onPhotoDataSuccess(imageData) {
      ImageSrc = "data:image/jpeg;base64," + imageData;
	  document.getElementById("image").innerHTML = "<img src = '" + ImageSrc + "' width = '100%'/>"
	  }
	  function onPhotoDataSuccess2(imageData) {
      ImageSrc = "data:image/jpeg;base64," + imageData;
	  document.getElementById("container2").innerHTML = "<img src = '" + ImageSrc + "' width = '100%'/>"
	  }
	  
	  function sendMessage(){
	  recipient = document.getElementById("recipient").value;
	  subject = "You got a new garfiti!";
	  message = document.getElementById("message").value;
	  writeGarf();
	  alert(attachment);
	  setTimeout(window.plugins.emailComposer.showEmailComposerWithCallback(null, subject,message,[recipient],[],[],true,["/mnt/sdcard/newMessage.txt"]), 1000);	  
	  //window.location = "open.html";
	  window.location = "index.html";
    }
	

    //
    function capturePhoto() {
	  
	    pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
      // Take picture using device camera and retrieve image as base64-encoded string
      navigator.camera.getPicture(onPhotoDataSuccess, onFail, { quality: 50,
        destinationType: destinationType.DATA_URL });
    }
	
	    function capturePhoto2() {
	  
	    pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
      // Take picture using device camera and retrieve image as base64-encoded string
      navigator.camera.getPicture(onPhotoDataSuccess2, onFail, { quality: 50,
        destinationType: destinationType.DATA_URL });
    }


    // A button will call this function
    //
    
    function onFail(message) {
      alert('Failed because: ' + message);
    }

	
	
        function writeGarf(){
			window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
		}
    

            function gotFS(fileSystem) {
                fileSystem.root.getFile("newMessage.txt", {create: true, exclusive: false}, gotFileEntry, fail);
            }

            function gotFileEntry(fileEntry) {
				attachment = fileEntry;
                fileEntry.createWriter(gotFileWriter, fail);
            }

            function gotFileWriter(writer) {
                writer.onwrite = function(evt) {
                    console.log("write success");
                };

                writer.write(document.getElementById("recipient").value + "\n" + document.getElementById("message").value + "\n" + document.getElementById("sender").value + "\n" + ImageSrc);
                writer.abort();
                // contents of file now 'some different text'
            }

            function fail(error) {
                console.log("error : "+error.code);
            }
			
		function openFile(){
			window.location = "open.html";
		}
			
	function startRead() {
        window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS2, fail);
    }

    function gotFS2(fileSystem) {
		var fullPath = document.getElementById('fileChoose').value;
        fileSystem.root.getFile(fullPath.replace(/^.*[\\\/]/, ''), null, gotFileEntry2, fail);
	
    }

    function gotFileEntry2(fileEntry) {
        fileEntry.file(gotFile, fail);
    }

    function gotFile(file){
        readAsText(file);		
    }

 

    function readAsText(file) {
		alert("read as text");
        var reader = new FileReader();
        reader.onloadend = function(evt) {
            console.log("Read as text");
           var text =  evt.target.result;
		   openFunction(text);
        };
       reader.readAsText(file);
	   
    }

    function fail(evt) {
        alert("Something went wrong");
    }
	
	function openFunction(text){
		lines = text.split("\n");
		var recipient = lines[0];
		
		var message = lines[1];
		
		var sender = lines[2];
		
		lines.splice(0,3);
		var base64IMG = lines.join('\n');
	
		document.getElementById("container1").innerHTML = "<img src = '" + base64IMG + "' width = '100%'  />";
		document.getElementById("heading").innerHTML = "Sent to: " + recipient + "<br />" +  "From: " + sender;
		document.getElementById("message").innerHTML = "'" + message + "'";
		document.getElementById("choose").innerHTML = "";
		document.getElementById("compare").innerHTML = "<input type = 'button' value = 'Match' onclick = 'success()'/><input type = 'button' value = 'Fail' onclick = 'failMatch()' />";
	}

	function success(){
		window.location = "success.html";
	}
	
	function failMatch(){
		window.location = "fail.html";
	}
	
	
